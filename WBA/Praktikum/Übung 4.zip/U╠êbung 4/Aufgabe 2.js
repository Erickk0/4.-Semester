/** Funktion, die die Zahlen 1-25 quadriert. */
function square(){
    var e = 2;
    for(var b = 0; b <= 25; b++){
        c = Math.pow(b, e);
        console.log(c);
    }
}