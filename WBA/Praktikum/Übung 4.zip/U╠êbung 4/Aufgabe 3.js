/**
 * Funktion, die den Betrag eines Vektors berechnet
 * @param {number} a - Spalten des Vektors
 */
function betrag(a) {
    console.log("|a|= ", Math.sqrt(a ** 2 + a ** 2));
}

/*
function betrag(a){
return Math.sqrt(a.x ** 2 + a.y ** 2);
}
let vektor = {x: 3, y: 4};
console.log("|a| =", betrag(vektor));*/